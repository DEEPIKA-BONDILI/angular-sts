import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-vehicle-details',
  templateUrl: './add-vehicle-details.component.html',
  styleUrls: ['./add-vehicle-details.component.css']
})
export class AddVehicleDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
