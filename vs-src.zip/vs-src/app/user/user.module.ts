import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddPersonalDetailsComponent } from './add-personal-details/add-personal-details.component';
import { AddVehicleDetailsComponent } from './add-vehicle-details/add-vehicle-details.component';
import { AddDocumentsComponent } from './add-documents/add-documents.component';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    AddPersonalDetailsComponent,
    AddVehicleDetailsComponent,
    AddDocumentsComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    FormsModule
  ],
  exports:[
    AddPersonalDetailsComponent,
    AddVehicleDetailsComponent,
    AddDocumentsComponent
  ]
})
export class UserModule { }
