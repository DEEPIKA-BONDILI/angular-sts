import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-documents',
  templateUrl: './add-documents.component.html',
  styleUrls: ['./add-documents.component.css']
})
export class AddDocumentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
