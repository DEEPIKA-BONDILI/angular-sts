import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CustomerCareService {

  constructor() { }
  phonecalls()
  {
    alert('Calling customers..');
  }
  complaint()
  {
    alert('Registering customers complaints..');
  }
}
