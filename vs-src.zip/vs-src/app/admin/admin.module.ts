import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VerificationComponent } from './verification/verification.component';
import { ApprovalComponent } from './approval/approval.component';



@NgModule({
  declarations: [
    VerificationComponent,
    ApprovalComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    VerificationComponent,
    ApprovalComponent
  ]
})
export class AdminModule { }
