import {Customer} from "./Customer";
export class employee{
    employeeNumber: number |undefined;
     employeeName: string |undefined;
     employeeJob: string |undefined;
     employeeCommission: number |undefined; 
     employeeManager: number |undefined;
     employeeSalary: number |undefined;
     employeeHireDate: string|undefined;
     custList: Customer[] | undefined;
}