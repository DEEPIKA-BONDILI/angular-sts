import { Component, OnInit } from '@angular/core';
import { CurrencyConverterService } from '../currency-converter.service';
import { CustomerCareService } from '../customer/customer-care.service';
import { Department } from './Department';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  prompt1='Enter Username';
  prompt2='Enter Password';

  uname='Deepika';
  upass='deepu10';

  isLoggedIn=false;
  allDepts=["Testing","Coading","Accounting","Marketing"]; //array of string

  toDayDate=new Date();

 Signin:boolean=true;
 Signout:boolean=false;
 
  mySignInFunction()
  {
    alert('Signin is clicked');
  }
  mySignOutFunction()
  {
    alert('SignOut is clicked');
  }

  dept: Department = new Department(); // it is an obj
  /*deptAry: Department[] = [
    {departmentNumber:10,departmentName:"Accounting",departmentLocation:"NewYork"},
    {departmentNumber:20,departmentName:"Coading",departmentLocation:"Hyderabad"},
    {departmentNumber:30,departmentName:"Marketing",departmentLocation:"Chennai"},
    {departmentNumber:40,departmentName:"Sales",departmentLocation:"Banglore"},
  ];*/
 /*
  deptAry: Department[] = [
    {
      "departmentNumber": 30,
      "departmentName": "SALES",
      "departmentLocation": "CHICAGO",
      "empSet": [
          {
              "employeeNumber": 7844,
              "employeeName": "TURNER",
              "employeeJob": "SALESMAN",
              "employeeManager": 7698,
              "employeeHireDate":"1981-09-08",
              "employeeSalary": 1500.0,
              "employeeCommission": 0.0,
              "custList": [
                  {
                      "customerid": 105,
                      "name": "K + T SPORTS",
                      "city": "SANTA CLARA",
                      "creditlimit": 5000.0
                  },
                  {
                      "customerid": 108,
                      "name": "NORTH WOODS HEALTH AND FITNESS SUPPLY CENTER",
                      "city": "HIBBING",
                      "creditlimit": 8000.0
                  },
                  {
                      "customerid": 100,
                      "name": "JOCKSPORTS",
                      "city": "BELMONT",
                      "creditlimit": 5000.0
                  }
              ]
          },
          {
              "employeeNumber": 7521,
              "employeeName": "WARD",
              "employeeJob": "SALESMAN",
              "employeeManager": 7698,
              "employeeHireDate": "1981-02-22",
              "employeeSalary": 1250.0,
              "employeeCommission": 500.0,
              "custList": [
                  {
                      "customerid": 101,
                      "name": "TKB SPORT SHOP",
                      "city": "REDWOOD CITY",
                      "creditlimit": 10000.0
                  },
                  {
                      "customerid": 103,
                      "name": "JUST TENNIS",
                      "city": "BURLINGAME",
                      "creditlimit": 3000.0
                  },
                  {
                      "customerid": 106,
                      "name": "SHAPE UP",
                      "city": "PALO ALTO",
                      "creditlimit": 6000.0
                  }
              ]
          },
          {
              "employeeNumber": 7499,
              "employeeName": "ALLEN",
              "employeeJob": "SALESMAN",
              "employeeManager": 7698,
              "employeeHireDate": "1981-02-20",
              "employeeSalary": 1600.0,
              "employeeCommission": 300.0,
              "custList": [
                  {
                      "customerid": 104,
                      "name": "EVERY MOUNTAIN",
                      "city": "CUPERTINO",
                      "creditlimit": 10000.0
                  },
                  {
                      "customerid": 107,
                      "name": "WOMENS SPORTS",
                      "city": "SUNNYVALE",
                      "creditlimit": 10000.0
                  }
              ]
          },
          {
              "employeeNumber": 7698,
              "employeeName": "BLAKE",
              "employeeJob": "MANAGER",
              "employeeManager": 7839,
              "employeeHireDate": "1981-05-01",
              "employeeSalary": 2850.0,
              "employeeCommission": undefined,
              "custList": []
          },
          {
              "employeeNumber": 7654,
              "employeeName": "MARTIN",
              "employeeJob": "SALESMAN",
              "employeeManager": 7698,
              "employeeHireDate": "1981-09-28",
              "employeeSalary": 1250.0,
              "employeeCommission": 1400.0,
              "custList": [
                  {
                      "customerid": 102,
                      "name": "VOLLYRITE",
                      "city": "BURLINGAME",
                      "creditlimit": 7000.0
                  }
              ]
          }
      ]
  }
  ];
*/
  //Account ary[] = new Account[4]; java array
  //ary[0]=new Account();
  //ary[1]=new Account();
  //ary[2]=new Account();

  dno : number=0;
  constructor(private css: CurrencyConverterService,private custCare:CustomerCareService) { }
  invokeServices()
  {
    this.css.convert();
    this.css.save();
    this.custCare.phonecalls();
    this.custCare.complaint();
  }

  ngOnInit(): void {
    this.dept.departmentNumber=10;
    this.dept.departmentName="Coading";
    this.dept.departmentLocation="Pune";
  }

  mySignIn()
 {
   this.Signin=!this.Signin;
   if(this.Signin)
   alert('Signout is clicked');
 
   this.Signout=!this.Signout;
   if(this.Signout)
   alert('Signin is clicked');
 }

 tempDept: Department= new Department();  //created an object of department
  findDepartmentByDeptno(dno: number){
      this.css.findDepartmentByDeptnoService(dno).subscribe((data)=>{
        if (data!=null) 
        {this.tempDept=data;}
        else{
          alert('unable to featch');
        }
        })
  }

  ShowMe:boolean=false
    ShowMe1:boolean=false
    ShowMe2:boolean=false
    ShowMe3:boolean=false
     toogleTag()
     {
       this.ShowMe=!this.ShowMe;
     }
     toogleTag1()
     {
       this.ShowMe1=!this.ShowMe1;
     }
     toogleTag2()
     {
       this.ShowMe2=!this.ShowMe2;
     }
     toogleTag3()
     {
       this.ShowMe3=!this.ShowMe3;
     }
}
