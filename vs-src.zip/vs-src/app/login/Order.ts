export class Order
{
 ordid :number|undefined;
 oderDate:Date|undefined;
 commplan:string|undefined;
 shipDate:Date|undefined;
 total :number|undefined;
 }
