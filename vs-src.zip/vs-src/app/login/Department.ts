import {employee} from "./Employee";
export class Department{
    
 departmentNumber : number | undefined;
	
 departmentName : string | undefined;
	
 departmentLocation : string | undefined;

 empSet: employee[] | undefined;
}


