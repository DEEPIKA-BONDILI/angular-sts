import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { Department } from './login/Department';

@Injectable({
  providedIn: 'root'
})
export class CurrencyConverterService {
 
  constructor(private myHttp: HttpClient) { }
  convert()
  {
    alert('Converting currency..');
  }
  save()
  {
    alert('Saving Converted currency..');
  }

  findDepartmentByDeptnoService(dno: number): Observable<Department> {
    return this.myHttp.get<Department>("http://localhost:8080/getDept/"+dno);   
}

addDepartmentService(dept: Department)  {
  return this.myHttp.post("http://localhost:8080/addDept",dept,{responseType:'text'});
   
}


modifyDepartmentService(dept: Department)  {
  return this.myHttp.put("http://localhost:8080/modifyDept",dept,{responseType:'text'});
   
}

deleteDepartmentService(dept: Department)  {
  return this.myHttp.delete("http://localhost:8080/deleteDeptById/"+dept.departmentNumber,{responseType:'text'})

   
}

}
