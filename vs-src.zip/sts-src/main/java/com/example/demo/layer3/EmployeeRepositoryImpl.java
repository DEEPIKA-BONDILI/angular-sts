package com.example.demo.layer3;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Department5;
import com.example.demo.layer2.Employee2;

@Repository
public class EmployeeRepositoryImpl implements EmployyeRepository {
	@Autowired
	EntityManager entityManager;
	@Override
	public void addEmployee(Employee2 ERef) {
		// TODO Auto-generated method stub

	}

	@Override
	public Employee2 findEmployeeByEmpno(int dno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<Employee2> findEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void modifyEmployee(Employee2 ERef) {
		// TODO Auto-generated method stub

	}

	@Override
	public void removeEmployee(int dno) {
		// TODO Auto-generated method stub

	}

	@Override
	public Set<Employee2> findEmployeesByDeptno(int dno) {
		
		Set<Employee2> empSet;
		//empSet = new HashSet<Employee2>();
		
		/*
		 * Department5 d = new Department5(); d.setDepartmentNumber(dno);
		 */
			Query query = entityManager.createQuery("from Employee2 e where deptno =:mydeptno",Employee2.class).setParameter("mydeptno", dno);
			//empSet = (Set<Employee2>) query.getResultList().stream().collect(Collectors.toSet());
			
			empSet = new HashSet(query.getResultList());
				
			
		return empSet;
	
	}

}
