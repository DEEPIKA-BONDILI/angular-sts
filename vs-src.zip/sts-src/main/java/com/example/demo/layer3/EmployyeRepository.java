package com.example.demo.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Employee2;

@Repository
public interface EmployyeRepository {
	
	void addEmployee(Employee2 ERef);   //C - add/create
	Employee2 findEmployeeByEmpno(int dno);     //R - find/reading
	Set<Employee2> findEmployees();     //R - find all/reading all
	void modifyEmployee(Employee2 ERef); //U - modify/update
	void removeEmployee(int dno); //D - remove/delete
	Set<Employee2> findEmployeesByDeptno(int dno);
}
