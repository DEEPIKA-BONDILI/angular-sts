package com.example.demo.layer2;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity(name="CUSTOMER")
public class Customer2 {
	@Id
	@Column(name="CUSTID")
	private int customerid;
	@Column(name="NAME",length = 45)
	private String name;
	@Column(name="CITY",length = 30)
	private String city;
	@Column(name="CREDITLIMIT")
	private double creditlimit;
	
	@ManyToOne
	@JoinColumn(name="REPID")
	private Employee2 empobj;
	
	//@OneToMany
	//@List<order> orderList =
	
	@OneToMany(mappedBy = "cust", fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	Set<Order> ordList = new HashSet<Order>();
	
	
	
	public Set<Order> getOrdList() {
		return ordList;
	}
	public void setOrdList(Set<Order> ordList) {
		this.ordList = ordList;
	}
	
	
	public int getCustomerid() {
		return customerid;
	}
	public Customer2() {
		super();
		System.out.println("customer2() contr.....");
		
		
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	public double getCreditlimit() {
		return creditlimit;
	}
	public void setCreditlimit(double creditlimit) {
		this.creditlimit = creditlimit;
	}
	@JsonIgnore
	public Employee2 getEmpobj() {
		return empobj;
	}
	public void setEmpobj(Employee2 empobj) {
		this.empobj = empobj;
	}
	/*
	 * @Override public String toString() { return "Customer2 [customerid=" +
	 * customerid + ", name=" + name + ", city=" + city + ", creditlimit=" +
	 * creditlimit + "]"; }
	 */
		
	
	
}
